function onWrSave(){   
    var form = View.panels.get('loanUpdate_detailsPanel');
    var applincome = form.getFieldValue('loan.applicantIncome');
    var loanamt = form.getFieldValue('loan.loanAmount');
    var eligib = form.getFieldValue('loan.eligibile');
//    var eligib = (applincome >= loanamt) ? "y":"n";	
	 if (applincome >= loanamt) {
    eligib = "y";
    } else {
    eligib = "n";
   }
    form.setFieldValue('loan.eligibile', eligib);
	form.save(); 
	
	
	
	
//    var mark_up_cost = roundToTwo(eval(mark_up_p / 100) * eval(cost_total));
//    var cost_less_markup = roundToTwo(mark_up_cost + eval(cost_total));
//    form.setFieldValue('loan.mark_up_cost', mark_up_cost);
//    form.setFieldValue('loan.cost_less_markup', cost_less_markup);
//    form.save();
}